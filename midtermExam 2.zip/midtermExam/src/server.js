const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

//Allows the posting and sets up the receiver and deliever of the email using the inputted email data.
//Possibly using the wrong port could be issue.
app.post('/register', async (req, res) => {
    const { username, firstName, lastName, email } = req.body;
    
    const transporter = nodemailer.createTransport({
        service: 'murraystate',
        auth: {
            user: 'rsprague1@murraystate.edu',
            pass: 'Wildcard1034!!!!',
        },
    });

    const mailOptions = {
        from: 'rsprague1@murraystate.edu',
        to: 'jowen22@murraystate.edu',
        subject: 'New Registration',
        text: 'Username: ${username}\nFirst Name: ${firstName}\nLast Name: ${lastName}\nEmail: ${email}',
    };

    try{
        await transporter.sendMail(mailOptions);
        res.status(200).send('Registration successful, email sent!');
    }
    catch (error) {
        res.status(500).send('Error sending email: ' + error.message);
    }
});

app.listen(PORT, () => {
    console.log('Server is running on http://localhost:${PORT}');
});