import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const WelcomePage = () => {
  const [formData, setFormData] = useState({
    username: '',
    firstname: '',
    lastname: '',
    email: '',
  });

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };
//Allows the submitting of the email to happen as the main operation
const handleSubmit = async (e) => {
  e.preventDefault();
  const response = await fetch('http://localhost:5173/register', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: json.stringify(formData),
  });
  const result = await response.text();
  alert(result);
}

  const navigate = useNavigate();

  const goToHomePage = () => {
    navigate('/'); // Navigate to the home page
  };
 //Creates a form that allows the input of registration data
    return (
      <div>
        <h1>Welcome to HackerCon</h1>
        <p>Welcome SuperHacker You Are Inz</p>

        <form onSubmit={handleSubmit}>
          <input name="username" placeholder="username" onChange={handleChange} required />
          <input name="firstName" placeholder="First Name" onChange={handleChange} required />
          <input name="lastName" placeholder="Last Name" onChange={handleChange} required />
          <input name="email" placeholder="Email" onChange={handleChange} required />
          <button type="submit">Register</button>
        </form>

        <button onClick={goToHomePage}>HOME</button>
      </div>
    );
  };
  
  export default WelcomePage;
  
  