import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const QuizPage = () => {
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const totalQuestions = 3; 

  const navigate = useNavigate();

  const goToWelcomePage = () => {
    navigate('/welcome'); // Navigate to the Welcome page
  };
  const handleAnswer = (isCorrect) => {
    if (isCorrect) {
      setCorrectAnswers((prev) => Math.min(prev + 1, totalQuestions));
      <button onClick={goToWelcomePage}>Submit Quiz</button>
    }
  };
 
    return (
      <div>
        <h1>Take Quiz to Qualify</h1>
        <p>Welcome to the qualifier quiz</p>
          <div>
          <p>What is the reason we use Express?</p>
          <textarea onChange={(e)=> SetText(e.target.value)}></textarea>
          </div>
          <div>
          <p>Give me two reasons why web services are useful for full stack web dev.</p>
          <textarea onChange={(e)=> SetText(e.target.value)}></textarea>
          </div>
          <div>
          <p>How do I pass data and objects from one react element to another?</p>
          <textarea onChange={(e)=> SetText(e.target.value)}></textarea>
          <div>
          <button onClick={() => handleAnswer(true)}>Click for how many you got correct</button> 
          <button onClick={() => handleAnswer(false)}>Click for how many you got wrong</button>
          </div>
          </div>
          <div>
          {correctAnswers === totalQuestions && (
          <button onClick={goToWelcomePage}>Submit Quiz</button>
          )}
          </div>
      </div>
    );
  };
  
  export default QuizPage;
  
  