import React from 'react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
const LoginPage = () => {
  const [text, SetText] = useState('')
  
  const navigate = useNavigate();

  const goToLoginPage = () => {
    navigate('/landing'); // Navigate to the Login page
  };
  function checkCreditenials(){
    var userName = 'rhylee' //The username and password are the same
    var passWord = 'rhylee' //Should thin out the overthinkers
    if(text == userName && text == passWord){
      navigate('/landing');
    }
 }
//Adds button for login.
    return (
      <div>
        <h1>Login Here</h1>
        <p>This is the Login Page. Type your given username and password.</p>
        <textarea onChange={(e)=> SetText(e.target.value)}></textarea>
            <button onClick={checkCreditenials()}>Take Qualifier Quiz</button>
      </div>
    );
  };
  
  export default LoginPage;
  